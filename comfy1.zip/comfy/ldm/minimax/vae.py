# MiniMax H3 video VAE: 3D causal CNN encoder + ViT3D decoder. The image VAEs pair the encoder with a single-frame ViT decoder.

import math

import torch
import torch.nn as nn
import torch.nn.functional as F

import comfy.model_management
import comfy.ops
import comfy.quant_ops
import comfy.rmsnorm
from comfy.ldm.modules.attention import COMFY_KITCHEN_INT8_ATTENTION_IS_AVAILABLE, optimized_attention

ops = comfy.ops.disable_weight_init

IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)

# p-h3-image: rope time coordinate of the decoded frame
PH3_IMAGE_FRAME_POSITION = 2.0 * (0.5 / 7) - 1.0
# the image VAEs condition on a posterior sample; the H3 keyframe recipe's seed
IMAGE_ENCODE_SEED = 42

LATENTS_MEAN = [
    0.858090341091156, -0.9606591463088989, 1.0661640167236328, -0.5090325474739075,
    -0.2727581858634949, -1.3675414323806763, -0.2553254961967468, -0.26907554268836975,
    -0.5376840829849243, -0.0464097298681736, 0.6657370328903198, 0.19690127670764923,
    -0.5460608005523682, -0.4035342037677765, -0.23683024942874908, 0.25928452610969543,
    -0.30133944749832153, 0.211341992020607, -1.1206848621368408, 0.3581933379173279,
    -0.04225143790245056, 0.2604829967021942, 0.22864092886447906, 0.7056031823158264,
]

LATENTS_STD = [
    1.2223774194717407, 1.2767263650894165, 1.68317747116088865, 1.7549455165863037,
    1.5636216402053833, 2.194143533706665, 0.96531379222869875, 1.05698859691619875,
    0.841948926448822, 0.7729952931404114, 1.8955937623977661, 0.946841835975647,
    0.7996809482574463, 0.44988900423049925, 0.7197399735450745, 0.69362932443618775,
    2.961095094680786, 2.7694199085235595, 3.0496184825897215, 2.1088054180145265,
    3.276226282119751, 3.1627357006073, 2.28168129920959475, 2.6127843856811525,
]


# 3D causal CNN encoder

def _kitchen_ndhwc(x):
    # NDHWC when the kitchen pad kernel can feed it and the conv consumes it natively:
    # cuDNN does, MIOpen converts back and loses more than the fused pad saves
    ck = getattr(comfy.quant_ops, "ck", None)
    return (ck is not None and hasattr(ck, "group_norm_silu_pad3d") and torch.version.hip is None
            and x.is_cuda and x.dtype in (torch.float16, torch.bfloat16))


def _fused_norm_pad(x, norm, spatial_pad, front):
    # per-frame GroupNorm + SiLU + padding in one kitchen pass, NDHWC out
    if not _kitchen_ndhwc(x) or x.shape[1] % 8:
        return None
    ck = comfy.quant_ops.ck
    if norm is None:
        return ck.group_norm_silu_pad3d(x, None, None, 1, 0.0, (*spatial_pad, front), silu=False)
    # cast_bias_weight: works for offloaded (dynamic VRAM) layers
    weight, bias, offload_stream = comfy.ops.cast_bias_weight(norm, x, offloadable=True)
    try:
        return ck.group_norm_silu_pad3d(x, weight, bias, norm.num_groups, norm.eps, (*spatial_pad, front), silu=True)
    finally:
        comfy.ops.uncast_bias_weight(norm, weight, bias, offload_stream)


def _fp16_accum_conv(conv, x, weight, bias, residual):
    # kitchen fp16-accumulate conv, same opt-in as the fp16 GEMMs
    ck = comfy.quant_ops.ck
    if not hasattr(ck, "fp16_conv3d") or not comfy.ops._fp16_linear_wanted(x):
        return None
    return ck.fp16_conv3d(x, weight, bias, residual, conv.stride)


class CausalConv3d(ops.Conv3d):
    # Reflect spatial padding, causal (zeros, front-only) temporal padding.
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0):
        super().__init__(in_channels, out_channels, kernel_size=kernel_size, stride=stride)
        self.causal_padding = (padding,) * 3 if isinstance(padding, int) else tuple(padding)

    def forward(self, x, pre_norm=None, spatial_pad=None, residual=None):
        # pre_norm, spatial_pad and residual fold into the kitchen pad pass and conv epilogue
        pad_t, pad_h, pad_w = self.causal_padding
        if spatial_pad is None:
            spatial_pad = (pad_w, pad_w, pad_h, pad_h)
        front = 0 if x.shape[2] == 1 else pad_t * 2

        ndhwc = _kitchen_ndhwc(x)
        if ndhwc and self.weight.is_cuda and not self.weight.is_contiguous(memory_format=torch.channels_last_3d):
            self.weight.data = self.weight.data.contiguous(memory_format=torch.channels_last_3d)

        if pre_norm is not None or front or any(spatial_pad):  # the 1x1 shortcut has nothing to fold
            fused = _fused_norm_pad(x, pre_norm, spatial_pad, front)
            if fused is not None:
                x = fused
            else:
                if pre_norm is not None:
                    x = F.silu(pre_norm(x), inplace=True)
                if any(spatial_pad):
                    x = F.pad(x, (*spatial_pad, 0, 0), mode="reflect")
                if front:
                    x = F.pad(x, (0, 0, 0, 0, front, 0), mode="constant")

        if x.shape[2] == 1 and pad_t:
            # single frame: the causal front padding is all zeros truncate the temporal taps instead of convolving zero frames
            out = super().forward(x, autopad="causal_zero")
        elif ndhwc:
            # cast_bias_weight handles offloaded layers; channels_last keeps cuDNN's output NDHWC
            weight, bias, offload_stream = comfy.ops.cast_bias_weight(self, x, offloadable=True)
            try:
                weight_cl = weight.contiguous(memory_format=torch.channels_last_3d)
                out = _fp16_accum_conv(self, x, weight_cl, bias, residual)
                if out is not None:
                    return out
                out = F.conv3d(x, weight_cl, bias, self.stride)
            finally:
                comfy.ops.uncast_bias_weight(self, weight, bias, offload_stream)
        else:
            out = super().forward(x)
        if residual is not None:
            out += residual
        return out


class TemporalIsolatedGroupNorm(ops.GroupNorm):
    # GroupNorm with statistics computed per frame (time merged into batch).
    def forward(self, x):
        if x.dim() == 5:
            b, c, t, h, w = x.shape
            x = x.permute(0, 2, 1, 3, 4).contiguous().view(b * t, c, 1, h, w)
            x = super().forward(x)
            return x.view(b, t, c, h, w).permute(0, 2, 1, 3, 4).contiguous()
        return super().forward(x)


def group_norm_3d(num_channels):
    return TemporalIsolatedGroupNorm(num_groups=32, num_channels=num_channels, eps=1e-6, affine=True)


class Downsample3D(nn.Module):
    def __init__(self, in_channels, out_channels, time_stride=1, space_stride=2):
        super().__init__()
        self.space_stride = space_stride
        self.conv = CausalConv3d(
            in_channels,
            out_channels,
            kernel_size=3,
            padding=(1, 0, 0),
            stride=(time_stride, space_stride, space_stride),
        )

    def forward(self, x):
        if self.space_stride == 2:
            return self.conv(x, spatial_pad=(0, 1, 0, 1))
        return self.conv(x)


class ResnetBlock3D(nn.Module):
    def __init__(self, in_channels, out_channels=None):
        super().__init__()
        self.in_channels = in_channels
        out_channels = in_channels if out_channels is None else out_channels
        self.out_channels = out_channels

        self.norm1 = group_norm_3d(in_channels)
        self.norm2 = group_norm_3d(out_channels)
        self.conv1 = CausalConv3d(in_channels, out_channels, kernel_size=3, padding=1)
        self.conv2 = CausalConv3d(out_channels, out_channels, kernel_size=3, padding=1)
        if in_channels != out_channels:
            self.nin_shortcut = CausalConv3d(in_channels, out_channels, kernel_size=1)

    def forward(self, x):
        h = self.conv1(x, pre_norm=self.norm1)
        if self.in_channels != self.out_channels:
            x = self.nin_shortcut(x)
        return self.conv2(h, pre_norm=self.norm2, residual=x)


class ResnetShortcut3D(nn.Module):
    # resnet block pruned down to its shortcut (LightVAE Lite encoder)
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.nin_shortcut = CausalConv3d(in_channels, out_channels, kernel_size=1) if in_channels != out_channels else nn.Identity()

    def forward(self, x):
        return self.nin_shortcut(x)


class EncoderFCN3D(nn.Module):
    def __init__(self, ch, ch_mult, space_down, time_down, num_res_blocks, in_channels, z_channels, double_z=True, kept_blocks=None):
        super().__init__()
        self.num_levels = len(ch_mult)
        if isinstance(num_res_blocks, int):
            num_res_blocks = [num_res_blocks] * self.num_levels
        self.num_res_blocks = num_res_blocks

        block_mid = [ch * ch_mult[i] for i in range(self.num_levels)]
        block_in = [block_mid[0]] + block_mid[:-1]
        block_out = block_mid

        self.conv_in = CausalConv3d(in_channels, block_in[0], kernel_size=3, padding=1)

        self.down = nn.ModuleList()
        for i_level in range(self.num_levels):
            down = nn.Module()
            down.block = nn.ModuleList()
            for i in range(self.num_res_blocks[i_level]):
                block = ResnetBlock3D if kept_blocks is None or (i_level, i) in kept_blocks else ResnetShortcut3D
                down.block.append(
                    block(
                        in_channels=block_in[i_level] if i == 0 else block_mid[i_level],
                        out_channels=block_mid[i_level],
                    )
                )
            if space_down[i_level] * time_down[i_level] > 1:
                down.downsample = Downsample3D(
                    block_mid[i_level],
                    block_out[i_level],
                    time_stride=time_down[i_level],
                    space_stride=space_down[i_level],
                )
            self.down.append(down)

        self.norm_out = group_norm_3d(block_out[-1])
        self.conv_out = CausalConv3d(
            block_out[-1],
            2 * z_channels if double_z else z_channels,
            kernel_size=3,
            padding=1,
        )

    def forward(self, x):
        h = self.conv_in(x)
        for i_level in range(self.num_levels):
            for i_block in range(self.num_res_blocks[i_level]):
                h = self.down[i_level].block[i_block](h)
            if hasattr(self.down[i_level], "downsample"):
                h = self.down[i_level].downsample(h)
        return self.conv_out(h, pre_norm=self.norm_out)


# ViT3D decoder

def unpatchify(output, B, T, H, W, out_channels, patch_size_t, patch_size):
    # [B, T*H*W, C*pt*p*p] token patches -> [B, C, T*pt, H*p, W*p] pixels
    output = output.view(B, T, H, W, out_channels, patch_size_t, patch_size, patch_size)
    return output.permute(0, 4, 1, 5, 2, 6, 3, 7).reshape(B, out_channels, T * patch_size_t, H * patch_size, W * patch_size)


def create_token_ids(patch_dims, device, dtype):
    coords_list = []
    for dim_size in patch_dims:
        coords = torch.arange(0.5, dim_size, dtype=dtype, device=device)
        coords = coords / dim_size
        coords = 2.0 * coords - 1.0
        coords_list.append(coords)
    coords = torch.stack(torch.meshgrid(*coords_list, indexing="ij"), dim=-1)
    return coords.flatten(0, len(patch_dims) - 1).unsqueeze(0)


class RotaryEmbeddingND(nn.Module):
    def __init__(self, dim, rotary_base=100.0, n_dim=3):
        super().__init__()
        self.n_dim = n_dim
        self.angle_scale = 2.0 * math.pi
        inv_freq = 1 / rotary_base ** torch.arange(0, 1, 2 * n_dim / dim, dtype=torch.float32)
        self.register_buffer("inv_freq", inv_freq, persistent=False)

    def forward(self, img_ids):
        # [B, S, n_dim] -> [B, S, 1, pairs, 2, 2] rotation table for the kitchen split-half rope
        angles = (
            self.angle_scale
            * img_ids[:, :, :, None].float()
            * self.inv_freq.to(img_ids.device)[None, None, None, :]
        )
        angles = angles.flatten(2, 3)
        c, s = torch.cos(angles), torch.sin(angles)
        table = torch.stack([c, -s, s, c], dim=-1).reshape(*angles.shape[:2], 1, angles.shape[-1], 2, 2)
        return table.to(img_ids.dtype)


class FeedForward(nn.Module):
    # Gated SiLU FFN.
    def __init__(self, dim, mult=4, bias=True, operations=ops):
        super().__init__()
        inner_dim = dim * mult
        self.w1 = operations.Linear(dim, inner_dim * 2, bias=bias)
        self.w2 = operations.Linear(inner_dim, dim, bias=bias)

    def forward(self, x, pre_norm, residual, residual_scale):
        # norm, gated silu and residual addcmul fold into the INT8 kernels
        h = comfy.ops.linear_input_act(self.w1, x, "rms_norm", act_weight=pre_norm)
        return comfy.ops.linear_input_act(self.w2, h, "swiglu", residual=residual, residual_scale=residual_scale)


class Attention(nn.Module):
    def __init__(self, heads, dim_head, bias=True, eps=1e-5, operations=ops):
        super().__init__()
        self.dim_head = dim_head
        self.heads = heads
        inner_dim = dim_head * heads
        self.norm_q = ops.RMSNorm(dim_head, eps=eps, elementwise_affine=False)
        self.norm_k = ops.RMSNorm(dim_head, eps=eps, elementwise_affine=False)
        # unit scale for the fused rms+rope kernel; the qk norms are not affine
        self.register_buffer("qk_norm_scale", torch.ones(dim_head), persistent=False)
        self.to_qkv = operations.Linear(inner_dim, inner_dim * 3, bias=bias)
        self.to_out = operations.Linear(inner_dim, inner_dim, bias=bias)

    def forward(self, x, rotary_pos_emb, pre_norm, residual=None, residual_scale=None):
        out = self.attend(x, rotary_pos_emb, pre_norm)
        return comfy.ops.linear_input_act(self.to_out, out, None, residual=residual, residual_scale=residual_scale)

    def attend(self, x, rotary_pos_emb, pre_norm):
        # [B, L, dim] -> attention output [B, L, dim], before the out-projection
        batch_size, seq_len, _ = x.shape

        qkv = comfy.ops.linear_input_act(self.to_qkv, x, "rms_norm", act_weight=pre_norm)
        qkv = qkv.view(batch_size, seq_len, -1, 3 * self.dim_head)
        query, key, value = torch.chunk(qkv, 3, dim=-1)

        if rotary_pos_emb is not None:
            query, key = self.rms_rope(query, key, rotary_pos_emb)
        else:
            query = comfy.rmsnorm.rms_norm(query, self.norm_q.weight, self.norm_q.eps)
            key = comfy.rmsnorm.rms_norm(key, self.norm_k.weight, self.norm_k.eps)

        return self.attention(*(t.transpose(1, 2) for t in (query, key, value)))

    def rms_rope(self, query, key, rotary_pos_emb):
        # fused per-head RMSNorm + partial split-half rope, in place when autograd is off
        rms_rope = (comfy.quant_ops.ck.rms_rope_split_half if torch.is_grad_enabled()
                    else comfy.quant_ops.ck.rms_rope_split_half_)
        # the eager fallback does no device alignment, so a CPU-resident (offloaded)
        # buffer must be moved to the input's device before the fused call
        return rms_rope(query, key, rotary_pos_emb, self.qk_norm_scale.to(query.device),
                        epsilon=self.norm_q.eps, rot_dim=rotary_pos_emb.shape[-3] * 2)

    def attention(self, query, key, value):
        # [B, heads, L, dh] (any key length) -> [B, L, dim]
        # an int8 decoder already accepts int8 numerics; fp16 keeps exact flash
        if isinstance(self.to_qkv.weight, comfy.ops.QuantizedTensor) and COMFY_KITCHEN_INT8_ATTENTION_IS_AVAILABLE:
            out = comfy.quant_ops.ck.int8_attention(query, key, value)
            out = out.transpose(1, 2).reshape(query.shape[0], query.shape[2], -1)
        else:
            out = optimized_attention(query, key, value, self.heads, skip_reshape=True)
        return torch.nan_to_num(out)


class TransformerBlock(nn.Module):
    def __init__(self, heads, dim_head, bias=True, eps=1e-5, operations=ops):
        super().__init__()
        dim = heads * dim_head
        self.norm1 = ops.RMSNorm(dim, elementwise_affine=True, eps=eps)
        self.attn = Attention(heads=heads, dim_head=dim_head, bias=bias, eps=eps, operations=operations)
        self.scale1 = nn.Parameter(torch.empty(dim))
        self.norm2 = ops.RMSNorm(dim, elementwise_affine=True, eps=eps)
        self.ff = FeedForward(dim=dim, bias=bias, operations=operations)
        self.scale2 = nn.Parameter(torch.empty(dim))

    def _residual_scale(self, scale, x):
        # cast_to_input always copies, defeating the kernels' identity-keyed caches
        if scale.dtype == x.dtype and scale.device == x.device:
            return scale
        return comfy.ops.cast_to_input(scale, x)

    def forward(self, x, rotary_pos_emb=None):
        return self.post_attention(self.attn.attend(x, rotary_pos_emb, self.norm1), x)

    def post_attention(self, out, x):
        # out-projection and feed-forward, each adding its scaled residual
        x = comfy.ops.linear_input_act(self.attn.to_out, out, None,
                                       residual=x, residual_scale=self._residual_scale(self.scale1, x))
        return self.ff(x, pre_norm=self.norm2, residual=x, residual_scale=self._residual_scale(self.scale2, x))


class ViT3DDecoder(nn.Module):
    def __init__(self, patch_size=16, patch_size_t=4, in_channels=24, out_channels=3, num_layers=36, heads=32, dim_head=64, rope_theta=100.0,
                 rope_dim_ratio=0.75, rope_dims=3, bias=True, eps=1e-5, num_register_tokens=4, operations=ops):
        super().__init__()
        dim = heads * dim_head
        self.patch_size = patch_size
        self.patch_size_t = patch_size_t
        self.out_channels = out_channels
        self.num_register_tokens = num_register_tokens

        # rope over the trailing rope_dims latent axes of (t, h, w)
        self.pos_embed = RotaryEmbeddingND(int(dim_head * rope_dim_ratio), rope_theta, n_dim=rope_dims)
        self.x_embedder = ops.Linear(in_channels, dim)
        self.register_tokens = nn.Parameter(torch.empty(1, num_register_tokens, dim))
        # unused at inference; kept so the checkpoint loads without leftover keys
        self.register_buffer("mask_token", torch.empty(1, 1, dim))

        self.transformer_blocks = nn.ModuleList(
            [TransformerBlock(heads=heads, dim_head=dim_head, bias=bias, eps=eps, operations=operations)
             for _ in range(num_layers)]
        )

        self.norm_out = ops.LayerNorm(dim, elementwise_affine=True, eps=eps)
        self.proj_out = ops.Linear(dim, out_channels * patch_size_t * patch_size * patch_size)

    def _token_ids(self, T, H, W, device, dtype):
        return create_token_ids((T, H, W)[-self.pos_embed.n_dim:], device, dtype)

    def forward(self, x):
        B, C, latent_T, latent_H, latent_W = x.shape

        h = self.x_embedder(x.flatten(2).transpose(1, 2))  # [B, T*H*W, C]

        num_patches = h.shape[1]
        num_suffix = 1 + self.num_register_tokens

        h = torch.cat([h, comfy.ops.cast_to_input(self.register_tokens, h).expand(B, -1, -1), torch.zeros_like(h[:, 0:1, :])], dim=1)

        img_ids = self._token_ids(latent_T, latent_H, latent_W, x.device, x.dtype).expand(B, -1, -1)
        suffix_ids = torch.zeros((B, num_suffix, self.pos_embed.n_dim), device=x.device, dtype=img_ids.dtype)
        img_ids = torch.cat([img_ids, suffix_ids], dim=1)

        rotary_pos_emb = self.pos_embed(img_ids)

        for block in self.transformer_blocks:
            h = block(h, rotary_pos_emb)

        output = self.proj_out(self.norm_out(h))

        return unpatchify(output[:, :num_patches, :], B, latent_T, latent_H, latent_W,
                          self.out_channels, self.patch_size_t, self.patch_size)


class PH3ImageDecoder(ViT3DDecoder):
    """p-h3-image decoder: one frame per latent, at a fixed rope time coordinate."""

    def __init__(self, **kwargs):
        super().__init__(patch_size_t=1, **kwargs)
        del self.mask_token

    def _token_ids(self, T, H, W, device, dtype):
        ids = create_token_ids((H, W), device, dtype)
        return torch.cat([torch.full_like(ids[..., :1], PH3_IMAGE_FRAME_POSITION), ids], dim=-1)


class NonCausalViT3DDecoder(nn.Module):
    """Sol-H3-VAE decoder: the ViT decoder pruned to 24 layers and distilled to decode a whole clip at once, so
    there is no spatial tiling and no temporal overlap recompute. Attention is local: 16x16-token spatial windows
    over 5-latent temporal windows (odd layers shift both by half a window), plus 5 global tokens per native
    5-latent block that attend to their whole block and are visible to every window of it. Rope ids are window-local.

    Tokens live in block-major rows (a block's tokens, then its global rows), so every linear layer runs on plain
    row chunks and only the residual stream and one layer's q/k/v ever span the clip."""

    max_windows = 64  # spatial windows per attention call
    ring = 2  # blocks of q/k/v/attention output live at once: a temporal window spans at most two blocks

    def __init__(self, patch_size=16, patch_size_t=4, in_channels=24, out_channels=3, num_layers=24, heads=32, dim_head=64,
                 rope_theta=100.0, rope_dim_ratio=0.75, bias=True, eps=1e-5, num_register_tokens=4,
                 window=16, block=5, time_shift=2, frames_to_trim=3, operations=ops):
        super().__init__()
        dim = heads * dim_head
        self.patch_size, self.patch_size_t, self.out_channels = patch_size, patch_size_t, out_channels
        self.heads, self.dim_head, self.dim = heads, dim_head, dim
        self.window, self.block, self.time_shift, self.frames_to_trim = window, block, time_shift, frames_to_trim
        self.num_global = num_register_tokens + 1
        self.x_embedder = operations.Linear(in_channels, dim, bias=bias)
        self.register_tokens = nn.Parameter(torch.empty(1, num_register_tokens, dim))
        self.blocks = nn.ModuleList(
            [TransformerBlock(heads=heads, dim_head=dim_head, bias=bias, eps=eps, operations=operations)
             for _ in range(num_layers)])
        self.norm_out = ops.LayerNorm(dim, eps=eps)
        self.proj_out = operations.Linear(dim, out_channels * patch_size_t * patch_size * patch_size, bias=bias)
        self.pos_embed = RotaryEmbeddingND(int(dim_head * rope_dim_ratio), rope_theta, n_dim=3)

    def _build_geometry(self, T, H, W):
        """CPU index tables for one latent shape: clip rows are block-major (a block's tokens in (t, y, x) order,
        then its global rows); q/k/v and attention outputs live in ring slots, slot b % ring holding block b."""
        ws, tb, S, R, HW = self.window, self.block, self.num_global, self.ring, H * W
        nb = -(-T // tb)
        starts = [min(b * tb, T) * HW + b * S for b in range(nb + 1)]
        slot_rows = tb * HW + S
        t = torch.arange(T)
        tblk = t // tb
        row = (torch.tensor(starts)[tblk] + (t - tblk * tb) * HW)[:, None, None] + torch.arange(HW).view(H, W)
        slot = row + ((tblk % R) * slot_rows - torch.tensor(starts)[tblk])[:, None, None]
        glob = torch.tensor(starts[1:])[:, None] - S + torch.arange(S)
        gslot = glob + ((torch.arange(nb) % R) * slot_rows - torch.tensor(starts[:nb]))[:, None]
        geo = {"rows": list(zip(starts, starts[1:])), "slot_rows": slot_rows, "tok": row.reshape(-1),
               "glob": glob.reshape(-1), "gslot": gslot, "shifts": []}

        def spans(n, shift, size):  # [lo, hi) of the windows along one axis, shifted by `shift`, clipped to [0, n)
            edges = ((max(i * size - shift, 0), min((i + 1) * size - shift, n)) for i in range(-(-(n + shift) // size)))
            return [(lo, hi) for lo, hi in edges if hi > lo]

        for s, st in ((0, 0), (ws // 2, self.time_shift)):
            # window-local rope ids in [-1, 1]; global rows keep 0, i.e. no rotation
            axes = [((torch.arange(n) + o) % m + 0.5) / m * 2 - 1 for n, o, m in ((T, st, tb), (H, s, ws), (W, s, ws))]
            ids = torch.zeros(starts[-1], 3)
            ids[row.reshape(-1)] = torch.stack(torch.meshgrid(*axes, indexing="ij"), -1).reshape(-1, 3)
            # a temporal window runs once its last block is in; a block's out-proj runs once its last window has
            windows_at, done_at = [[] for _ in range(nb)], [0] * nb
            for t_lo, t_hi in spans(T, st, tb):
                blocks = sorted({t_lo // tb, (t_hi - 1) // tb})
                gk = gslot[blocks].reshape(-1)
                groups = {}  # spatial windows batched by shape; keys = own tokens + the blocks' global rows
                for y_lo, y_hi in spans(H, s, ws):
                    for x_lo, x_hi in spans(W, s, ws):
                        qi = slot[t_lo:t_hi, y_lo:y_hi, x_lo:x_hi].reshape(-1)
                        groups.setdefault(len(qi), []).append((qi, torch.cat([qi, gk])))
                for wins in groups.values():
                    for c in range(0, len(wins), self.max_windows):
                        windows_at[blocks[-1]].append(tuple(torch.stack(t) for t in zip(*wins[c:c + self.max_windows])))
                for b in blocks:
                    done_at[b] = max(done_at[b], blocks[-1])
            blocks_at = [[c for c in range(nb) if done_at[c] == b] for b in range(nb)]
            geo["shifts"].append({"ids": ids, "windows_at": windows_at, "blocks_at": blocks_at})
        return geo

    def iter_decode(self, z):
        """z: [1, C, T, H, W] -> yields (first frame index, pixels [1, 3, F, 16H, 16W]) per native block.

        Only the residual stream spans the clip; each layer streams over blocks with a ring of q/k/v slots."""
        _, C, T, H, W = z.shape
        heads, dh, D, S, R = self.heads, self.dim_head, self.dim, self.num_global, self.ring
        dev = z.device
        geo = self._build_geometry(T, H, W)
        rows, slot_rows = geo["rows"], geo["slot_rows"]
        gslot = geo["gslot"].to(dev)
        shifts = [(sh["ids"].to(dev), [[(qi.to(dev), ki.to(dev)) for qi, ki in wins] for wins in sh["windows_at"]],
                   sh["blocks_at"]) for sh in geo["shifts"]]
        x = torch.empty(rows[-1][1], D, dtype=z.dtype, device=dev)
        x[geo["tok"].to(dev)] = self.x_embedder(z[0].permute(1, 2, 3, 0).reshape(-1, C))
        x[geo["glob"].to(dev)] = torch.cat([comfy.ops.cast_to_input(self.register_tokens[0], x), x.new_zeros(1, D)], 0).repeat(len(rows), 1)
        q, k, v = (torch.empty(R * slot_rows, heads, dh, dtype=z.dtype, device=dev) for _ in range(3))
        attn_out = torch.empty(R * slot_rows, D, dtype=z.dtype, device=dev)
        for li, blk in enumerate(self.blocks):
            attn, (ids, windows_at, blocks_at) = blk.attn, shifts[li % 2]
            for b, (r0, r1) in enumerate(rows):
                s0 = (b % R) * slot_rows
                s1 = s0 + r1 - r0
                qkv = comfy.ops.linear_input_act(attn.to_qkv, x[r0:r1], "rms_norm", act_weight=blk.norm1)
                qq, kk, vv = qkv.view(1, r1 - r0, heads, 3 * dh).chunk(3, -1)
                qq, kk = attn.rms_rope(qq, kk, self.pos_embed(ids[None, r0:r1].to(z.dtype)))
                q[s0:s1], k[s0:s1], v[s0:s1] = qq[0], kk[0], vv[0]
                for qi, ki in windows_at[b]:
                    attn_out[qi] = attn.attention(*(t.transpose(1, 2) for t in (q[qi], k[ki], v[ki])))
                # the global rows attend to their whole block: too few queries to be worth re-quantizing the block
                gs = gslot[b]
                attn_out[gs] = optimized_attention(*(t[None].transpose(1, 2) for t in (q[gs], k[s0:s1], v[s0:s1])),
                                                   heads, skip_reshape=True)[0]
                for c in blocks_at[b]:
                    c0, c1 = rows[c]
                    cs = (c % R) * slot_rows
                    x[c0:c1] = blk.post_attention(attn_out[cs:cs + c1 - c0], x[c0:c1])
        del q, k, v, attn_out, shifts
        f0 = 0
        for r0, r1 in rows:
            y = unpatchify(self.proj_out(self.norm_out(x[r0:r1 - S]))[None], 1, (r1 - r0 - S) // (H * W), H, W,
                           self.out_channels, self.patch_size_t, self.patch_size)
            y = y[:, :, self.frames_to_trim:]  # the first latent of a block keeps one of its four frames
            yield f0, y
            f0 += y.shape[2]


# Full VAE

class MiniMaxH3VideoVAE(nn.Module):
    comfy_has_chunked_io = True

    def __init__(
        self,
        in_channels=3,
        out_ch=3,
        ch=128,
        embed_dim=24,
        z_channels=24,
        ch_mult=(1, 2, 2, 4, 4, 8),
        num_res_blocks=2,
        space_down=(2, 2, 2, 2, 1, 1),
        time_down=(1, 2, 2, 1, 1, 1),
        clip_length=17,
        token_drop=3,
        tile_size=256,
        tile_overlap_min=64,
        tiling=True,
        operations=ops,
        num_layers=36,
        still_frame=None,
        encoder_kept_blocks=None,
        encoder=True,
        decoder=True,
        noncausal_decoder=False,
    ):
        super().__init__()
        self.vae_ratio = int(math.prod(space_down))
        self.vae_ratio_t = int(math.prod(time_down))

        # temporal chunking parameters
        self.clip_length = clip_length
        self.token_drop = token_drop
        self.frame_pre_padding = (-clip_length) % self.vae_ratio_t
        self.tokens_chunk_size = math.ceil(clip_length / self.vae_ratio_t)
        self.token_overlap = (-token_drop) % self.tokens_chunk_size
        self.frame_overlap = max(self.token_overlap * self.vae_ratio_t - self.frame_pre_padding, 0)

        # a decoder fine-tuned to decode one latent directly keeps this output frame of it
        if still_frame is not None and not 0 <= still_frame < self.vae_ratio_t:
            raise ValueError(f"still_frame must be in [0, {self.vae_ratio_t}), got {still_frame}")
        self.still_frame = still_frame

        # spatial tiling parameters
        self.tiling = tiling
        self.tile_size = tile_size
        self.tile_overlap_min = tile_overlap_min

        if encoder:
            self.encoder = EncoderFCN3D(
                ch=ch,
                ch_mult=list(ch_mult),
                space_down=list(space_down),
                time_down=list(time_down),
                num_res_blocks=num_res_blocks,
                in_channels=in_channels,
                z_channels=z_channels,
                double_z=True,
                kept_blocks=encoder_kept_blocks,
            )
            self.quant_conv = ops.Conv3d(z_channels * 2, 2 * embed_dim, 1)
        # Sol-H3-VAE: a distilled decoder that takes the whole clip at once, no tiling or temporal chunking
        self.noncausal = noncausal_decoder
        if decoder:
            self.post_quant_conv = ops.Conv3d(embed_dim, z_channels, 1)
            decoder_cls = NonCausalViT3DDecoder if noncausal_decoder else ViT3DDecoder
            self.decoder = decoder_cls(
                patch_size=self.vae_ratio,
                patch_size_t=self.vae_ratio_t,
                in_channels=z_channels,
                out_channels=out_ch,
                num_layers=num_layers,
                operations=operations,
            )

        self.register_buffer("latents_mean", torch.tensor(LATENTS_MEAN))
        self.register_buffer("latents_std", torch.tensor(LATENTS_STD))
        self.register_buffer("pixel_mean", torch.tensor(IMAGENET_MEAN).view(1, 3, 1, 1, 1), persistent=False)
        self.register_buffer("pixel_std", torch.tensor(IMAGENET_STD).view(1, 3, 1, 1, 1), persistent=False)

    # single-shot forward

    def _encode_moments(self, x):
        return self.quant_conv(self.encoder(x))

    def _decode_pixels(self, z):
        return self.decoder(self.post_quant_conv(z))

    def _normalize_pixels(self, x):
        return x.add(1.0).mul_(0.5).sub_(self.pixel_mean.to(x)).div_(self.pixel_std.to(x))

    def _finalize_pixels(self, part):
        # raw decoder output -> float32 pixels in [0, 1] (the VAE wrapper's process_output is identity)
        part = part * self.pixel_std.to(device=part.device, dtype=torch.float32)
        return part.add_(self.pixel_mean.to(device=part.device, dtype=torch.float32)).clamp_(0.0, 1.0)

    def decode_output_shape(self, input_shape):
        b, c, t, h, w = input_shape
        if self.noncausal:
            # four frames per latent, the first latent of every 5-latent block keeps one
            frames = t * self.vae_ratio_t - self.decoder.frames_to_trim * -(-t // self.decoder.block)
        elif t == 1:
            frames = 1
        else:
            pad_tokens, num_chunks = self._decode_temporal_chunks(t)
            frames = self._decode_temporal_frame_plan(t + pad_tokens, num_chunks, pad_tokens)
        return (b, self.decoder.out_channels, frames, h * self.vae_ratio, w * self.vae_ratio)

    def _adaptive_encode(self, x):
        if self.tiling:
            return self.tiled_encode(x)
        return self._encode_moments(x)

    def _adaptive_decode(self, z, frames=slice(None)):
        if self.tiling:
            return self.tiled_decode(z, frames)
        return self._decode_pixels(z)[:, :, frames]

    # spatial tiling

    def split_tiles(self, input_len):
        tile_size = self.tile_size
        if tile_size >= input_len:
            return [0], [input_len], []

        N = math.ceil(input_len / tile_size)
        while True:
            overlaps = [self.tile_overlap_min] * (N - 1)
            remaining = tile_size * N - sum(overlaps) - input_len
            if remaining < 0:
                N += 1
            else:
                break

        remaining_units = remaining // self.vae_ratio
        for i in range(remaining_units):
            overlaps[i % (N - 1)] += self.vae_ratio

        tile_start_idx = [0]
        for i in range(N - 1):
            tile_start_idx.append(tile_start_idx[-1] + tile_size - overlaps[i])

        return tile_start_idx, [tile_size] * N, overlaps

    def blend(self, a, b, blend_extent, dim):
        blend_extent = min(a.shape[dim], b.shape[dim], blend_extent)

        positions = torch.arange(blend_extent, device=b.device, dtype=b.dtype)
        weight_a = 1 - positions / blend_extent
        weight_b = positions / blend_extent

        shape = [1] * a.ndim
        shape[dim] = blend_extent
        weight_a = weight_a.view(shape)
        weight_b = weight_b.view(shape)

        slice_a = [slice(None)] * a.ndim
        slice_a[dim] = slice(-blend_extent, None)
        slice_b = [slice(None)] * b.ndim
        slice_b[dim] = slice(0, blend_extent)

        blended = a[tuple(slice_a)] * weight_a + b[tuple(slice_b)] * weight_b

        if blend_extent < b.shape[dim]:
            slice_b_rest = [slice(None)] * b.ndim
            slice_b_rest[dim] = slice(blend_extent, None)
            return torch.cat([blended, b[tuple(slice_b_rest)]], dim=dim)
        return blended

    def tiled_encode(self, x):
        height, width = x.shape[-2], x.shape[-1]
        y_idx, y_len, y_overlap = self.split_tiles(height)
        x_idx, x_len, x_overlap = self.split_tiles(width)

        rows = []
        for i_pos, i_len in zip(y_idx, y_len):
            row = []
            for j_pos, j_len in zip(x_idx, x_len):
                tile = x[..., i_pos:i_pos + i_len, j_pos:j_pos + j_len]
                row.append(self._encode_moments(tile))
            rows.append(row)

        latent_y_overlap = [o // self.vae_ratio for o in y_overlap]
        latent_x_overlap = [o // self.vae_ratio for o in x_overlap]

        result_rows = []
        for i, row in enumerate(rows):
            result_row = []
            for j, tile in enumerate(row):
                if i > 0:
                    tile = self.blend(rows[i - 1][j], tile, latent_y_overlap[i - 1], dim=-2)
                if j > 0:
                    tile = self.blend(row[j - 1], tile, latent_x_overlap[j - 1], dim=-1)
                if i < len(rows) - 1:
                    tile = tile[..., :-latent_y_overlap[i], :]
                if j < len(row) - 1:
                    tile = tile[..., :, :-latent_x_overlap[j]]
                result_row.append(tile)
            result_rows.append(torch.cat(result_row, dim=-1))
        return torch.cat(result_rows, dim=-2)

    def _decode_tile_row(self, z_row, x_idx, x_len):
        # a few tiles per decoder call (~7%); each extra tile holds ~100 MB of activations
        free = comfy.model_management.get_free_memory(z_row.device)
        batch = int(max(1, min(4, free // (128 * 2**20 * z_row.shape[0]))))
        slices = [z_row[..., j_pos // self.vae_ratio:(j_pos + j_len) // self.vae_ratio] for j_pos, j_len in zip(x_idx, x_len)]
        for k in range(0, len(slices), batch):
            group = slices[k:k + batch]
            yield from self._decode_pixels(torch.cat(group)).chunk(len(group))

    def tiled_decode(self, z, frames=slice(None)):
        height, width = z.shape[-2] * self.vae_ratio, z.shape[-1] * self.vae_ratio
        y_idx, y_len, y_overlap = self.split_tiles(height)
        x_idx, x_len, x_overlap = self.split_tiles(width)

        # Blended tiles are written straight into a pre-allocated canvas. Tiles blend against
        # their neighbours as already blended, so seams stay continuous where overlaps cross.
        canvas = None
        strip = None
        out_y = 0
        for i, (i_pos, i_len) in enumerate(zip(y_idx, y_len)):
            zi, zl = i_pos // self.vae_ratio, i_len // self.vae_ratio
            tiles = self._decode_tile_row(z[..., zi:zi + zl, :], x_idx, x_len)
            new_strip = None
            left_tail = None
            out_x = 0
            # enumerate would retain the previous tile while the next batch decodes.
            for j in range(len(x_idx)):
                tile = next(tiles)[:, :, frames]
                if i > 0:
                    tile = self.blend(strip[..., :, x_idx[j]:x_idx[j] + x_len[j]], tile, y_overlap[i - 1], dim=-2)
                if j > 0:
                    tile = self.blend(left_tail, tile, x_overlap[j - 1], dim=-1)
                left_tail = tile[..., :, -x_overlap[j]:].clone() if j < len(x_idx) - 1 else None
                if j < len(x_idx) - 1:
                    tile = tile[..., :, :-x_overlap[j]]
                if canvas is None:
                    canvas = torch.empty(*tile.shape[:-2], height, width, dtype=tile.dtype, device=tile.device)
                if i < len(y_idx) - 1:
                    if new_strip is None:
                        new_strip = torch.empty(*tile.shape[:-2], y_overlap[i], width, dtype=tile.dtype, device=tile.device)
                    new_strip[..., :, out_x:out_x + tile.shape[-1]] = tile[..., -y_overlap[i]:, :]
                    tile = tile[..., :-y_overlap[i], :]
                canvas[..., out_y:out_y + tile.shape[-2], out_x:out_x + tile.shape[-1]].copy_(tile)
                tile_height = tile.shape[-2]
                out_x += tile.shape[-1]
                del tile
            strip = new_strip
            out_y += tile_height
        return canvas

    # temporal chunking

    def encode_temporal(self, x, device):
        # chunked input io: x may live on the CPU, clips move to the device as they encode
        z_list = []
        for i in range(math.ceil(x.shape[2] / self.clip_length)):
            clip_x = x[:, :, i * self.clip_length:(i + 1) * self.clip_length, :, :].to(device)
            if clip_x.shape[2] < self.clip_length:
                pad_frames = clip_x[:, :, -1:].repeat(1, 1, self.clip_length - clip_x.shape[2], 1, 1)
                clip_x = torch.cat([clip_x, pad_frames], dim=2)
            z_list.append(self._adaptive_encode(self._normalize_pixels(clip_x)))

        z = torch.cat(z_list, dim=2)
        if self.token_drop > 0:
            z = z[:, :, :-self.token_drop]
        return z

    def _decode_temporal_pad_frames(self, z_len, pad_tokens):
        if pad_tokens <= 0:
            return 0
        intra_tail = self.clip_length % self.vae_ratio_t
        if intra_tail == 0:
            return pad_tokens * self.vae_ratio_t

        z_len_before_pad = z_len - pad_tokens
        return sum(
            (intra_tail if (z_len_before_pad + k) % self.tokens_chunk_size == 0
             else self.vae_ratio_t)
            for k in range(pad_tokens)
        )

    def _decode_temporal_frame_plan(self, z_len, num_chunks, pad_tokens):
        chunk_dec = self.tokens_chunk_size * self.vae_ratio_t
        split_count = int(self.token_drop > 0) + 1
        total_frames = 0
        final_overlap_frames = 0

        for i in range(num_chunks):
            t_start_idx = i * self.tokens_chunk_size
            t_end_idx = t_start_idx + self.tokens_chunk_size + self.token_overlap
            clip_token_len = max(0, min(t_end_idx, z_len) - min(t_start_idx, z_len))
            clip_frame_len = clip_token_len * self.vae_ratio_t

            for j in range(split_count):
                f_start_idx = j * chunk_dec
                f_end_idx = min(f_start_idx + chunk_dec, clip_frame_len)
                chunk_frames = max(0, f_end_idx - f_start_idx - self.frame_pre_padding)
                if j == 0:
                    total_frames += chunk_frames
                else:
                    final_overlap_frames = chunk_frames

        total_frames += final_overlap_frames
        return total_frames - self._decode_temporal_pad_frames(z_len, pad_tokens)

    def _decode_temporal_chunks(self, z_len):
        pseudo_total_tokens = z_len + self.token_drop
        pad_tokens = (-pseudo_total_tokens) % self.tokens_chunk_size
        pseudo_total_tokens += pad_tokens

        num_chunks = pseudo_total_tokens // self.tokens_chunk_size - int(self.token_drop > 0)
        if num_chunks < 1:
            # too few tokens for one chunk (e.g. T_lat == 2): pad one extra chunk
            pad_tokens += self.tokens_chunk_size
            num_chunks += 1
        return pad_tokens, num_chunks

    def decode_noncausal(self, z, output_buffer=None):
        # the whole clip decodes in one pass; blocks of finalized frames stream out as they come off the head
        if output_buffer is None:
            output_buffer = torch.empty(self.decode_output_shape(z.shape), dtype=torch.float32,
                                        device=comfy.model_management.intermediate_device())
        still = z.shape[2] == 1
        if still:
            # a lone latent decodes badly here too; the first frame of a full block of copies is as good as
            # the stock decoder's still path
            z = z.repeat(1, 1, self.decoder.block, 1, 1)
        for i in range(z.shape[0]):
            for f0, part in self.decoder.iter_decode(self.post_quant_conv(z[i:i + 1])):
                if still:
                    output_buffer[i:i + 1].copy_(self._finalize_pixels(part[:, :, :1]))
                    break
                output_buffer[i:i + 1, :, f0:f0 + part.shape[2]].copy_(self._finalize_pixels(part))
        return output_buffer

    def decode_temporal(self, z, output_buffer=None):
        chunk_dec = self.tokens_chunk_size * self.vae_ratio_t
        split_count = int(self.token_drop > 0) + 1

        if output_buffer is None:
            # finalized chunks stream out of VRAM so the full video never sits on the GPU
            output_buffer = torch.empty(self.decode_output_shape(z.shape), dtype=torch.float32,
                                        device=comfy.model_management.intermediate_device())

        pad_tokens, num_chunks = self._decode_temporal_chunks(z.shape[2])
        if pad_tokens > 0:
            pad_z = z[:, :, -1:, :, :].repeat(1, 1, pad_tokens, 1, 1)
            z = torch.cat([z, pad_z], dim=2)

        dec = output_buffer
        dec_overlap = None
        write_pos = 0

        def write_part(part):
            nonlocal write_pos
            part_frames = part.shape[2]
            if part_frames <= 0:
                return
            part = self._finalize_pixels(part)
            copy_frames = min(part_frames, max(0, dec.shape[2] - write_pos))
            if copy_frames > 0:
                dec[:, :, write_pos:write_pos + copy_frames, :, :].copy_(
                    part[:, :, :copy_frames, :, :]
                )
                write_pos += copy_frames

        for i in range(num_chunks):
            t_start_idx = i * self.tokens_chunk_size
            t_end_idx = t_start_idx + self.tokens_chunk_size + self.token_overlap
            clip_z = z[:, :, t_start_idx:t_end_idx, :, :]

            clip_dec = self._adaptive_decode(clip_z)

            for j in range(split_count):
                f_start_idx = j * chunk_dec
                f_end_idx = min(f_start_idx + chunk_dec, clip_dec.shape[2])
                clip_dec_chunk = clip_dec[:, :, f_start_idx:f_end_idx, :, :]
                clip_dec_chunk = clip_dec_chunk[:, :, self.frame_pre_padding:, :, :]

                if j == 0:
                    if dec_overlap is not None:
                        clip_dec_chunk = self.blend(
                            dec_overlap, clip_dec_chunk, self.frame_overlap, dim=-3
                        )
                        dec_overlap = None
                    write_part(clip_dec_chunk)
                else:
                    dec_overlap = clip_dec_chunk.contiguous()

            if i == num_chunks - 1 and dec_overlap is not None:
                write_part(dec_overlap)
                dec_overlap = None

            del clip_dec, clip_z, clip_dec_chunk

        return dec


    def encode(self, x, device=None):
        # x: [B, 3, T, H, W] in [-1, 1] -> normalized latents [B, 24, T_lat, H/16, W/16]
        if x.ndim == 4:
            x = x.unsqueeze(2)
        if device is None:
            device = x.device

        if x.shape[2] == 1:
            moments = self._adaptive_encode(self._normalize_pixels(x.to(device)))
            moments = moments[:, :, -1:, :, :]
        else:
            moments = self.encode_temporal(x, device)

        mean = torch.chunk(moments.float(), 2, dim=1)[0]

        latents_mean = self.latents_mean.view(1, -1, 1, 1, 1).to(mean)
        latents_std = self.latents_std.view(1, -1, 1, 1, 1).to(mean)
        return (mean - latents_mean) / latents_std

    def encode_tiled(self, x, **kwargs):
        # tiling is always on internally with the reference's semantic tile sizes, ignore tiling fallbacks
        return self.encode(x)

    def decode_tiled(self, z, **kwargs):
        # tiling is always on internally (the Sol decoder cannot tile at all); ignore tiling fallbacks
        return self.decode(z)

    def decode(self, z, output_buffer=None):
        # z: [B, 24, T_lat, H_lat, W_lat] normalized latents -> float32 pixels [B, 3, T, H, W] in [0, 1]
        latents_mean = self.latents_mean.view(1, -1, 1, 1, 1).to(z)
        latents_std = self.latents_std.view(1, -1, 1, 1, 1).to(z)
        z = z * latents_std + latents_mean

        if self.noncausal:
            return self.decode_noncausal(z, output_buffer)
        if z.shape[2] == 1:
            if self.still_frame is not None:
                dec = self._adaptive_decode(z, slice(self.still_frame, self.still_frame + 1))
            else:
                # A still latent is the first latent of a clip and decodes badly alone: decode it as a
                # full clip of copies and keep only its first real frame.
                first = slice(self.frame_pre_padding, self.frame_pre_padding + 1)
                dec = self._adaptive_decode(z.repeat(1, 1, self.tokens_chunk_size, 1, 1), first)
            dec = self._finalize_pixels(dec)
            if output_buffer is None:
                return dec
            output_buffer.copy_(dec)
            return output_buffer
        return self.decode_temporal(z, output_buffer)


class H3ImageVAE(MiniMaxH3VideoVAE):
    """The H3 encoder with a single-frame decoder; subclasses attach the decoder."""

    def __init__(self):
        super().__init__(still_frame=0, decoder=False)

    def encode(self, x, device=None):
        # x: [B, 3, 1, H, W] in [-1, 1]
        moments = self._adaptive_encode(self._normalize_pixels(x.to(device=device)))
        mean, logvar = moments.float().chunk(2, dim=1)
        noise = torch.randn(mean.shape, generator=torch.Generator().manual_seed(IMAGE_ENCODE_SEED)).to(mean.device)
        latents = torch.addcmul(mean, torch.exp(0.5 * logvar.clamp(-30.0, 20.0)), noise)
        return (latents - self.latents_mean.view(1, -1, 1, 1, 1).to(latents)) / self.latents_std.view(1, -1, 1, 1, 1).to(latents)

    def decode(self, z, output_buffer=None):
        if z.shape[2] != 1:
            raise ValueError(f"This image VAE decodes single-frame image latents only, got {z.shape[2]} latent frames")
        return super().decode(z, output_buffer)


class PH3ImageVAE(H3ImageVAE):
    """p-h3-image: a 3D-rope ViT decoder at a fixed time coordinate."""

    def __init__(self, operations=ops, num_layers=36):
        super().__init__()
        self.post_quant_conv = ops.Conv3d(24, 24, 1)
        self.decoder = PH3ImageDecoder(patch_size=self.vae_ratio, num_layers=num_layers, operations=operations)


class MiniMaxH3ImageVAE(H3ImageVAE):
    """MiniMax-H3-Image: a 2D ViT decoder (16 heads, 2D rope over half the head)."""

    def __init__(self, operations=ops, num_layers=24):
        super().__init__()
        self.post_quant_conv = ops.Conv2d(24, 24, 1)
        self.decoder = ViT3DDecoder(patch_size=self.vae_ratio, patch_size_t=1, num_layers=num_layers, heads=16,
                                    rope_dim_ratio=0.5, rope_dims=2, operations=operations)

    def _decode_pixels(self, z):
        # the 2D post-quant conv takes the single frame; the decoder keeps the video layout with T = 1
        return self.decoder(self.post_quant_conv(z.squeeze(2)).unsqueeze(2))
